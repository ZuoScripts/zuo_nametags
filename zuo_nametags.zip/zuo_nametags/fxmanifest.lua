fx_version 'cerulean'
game 'gta5'

lua54 'yes'

description 'Zuo-Nametags, best Nametags System in FiveM'
author 'Zuo Services'

client_scripts {
    'client/client.lua'
}

server_scripts {
    'server/server.lua'
}