Citizen.CreateThread(function()
    Citizen.Wait(2000)
    print("^5-<---------------------------------------------->-")
    print[[^5  
  ______              _____                 _               
 |___  /             / ____|               (_)               
    / /_   _  ___   | (___   ___ _ ____   ___  ___ ___  ___ 
   / /| | | |/ _ \   \___ \ / _ \ '__\ \ / / |/ __/ _ \/ __|
  / /_| |_| | (_) |  ____) |  __/ |   \ V /| | (_|  __/\__ \
 /_____\__,_|\___/  |_____/ \___|_|    \_/ |_|\___\___||___/                             
]]
    print("^5-<---------------------------------------------->-")
    Citizen.Wait(1000)
    print("^4zuo-nametags - ^0loaded (file : ^9client.lua^0) ^2successfully!^0")
    Citizen.Wait(1000)
    print("^4zuo-nametags - ^0loaded (file : ^9server.lua^0) ^2successfully!^0")
end)
